# Score! :: Change Log

* 2020-0122: 0.0.1.0 (Lisias) for KSP >= 1.2.2 ALPHA
	+ First Alpha Release as Proof of Concept
	+ GUI is minimalist
	+ Only [Fastest Juno Powered Aircraft](https://forum.kerbalspaceprogram.com/index.php?/topic/191034-fastest-juno-powered-airplane/) Challenge is supported at the moment.
		- And take "supported" with a huge grain of salt. :)
  	